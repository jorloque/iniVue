new Vue({
  el: '#app',
  data: {
    text:'Hola Mundo',
  },
});
