var setDate = new Date(),
  locale = "es-ES",
  dateOptions = {weekday: 'long', month: 'long', day:'numeric'}
  readableDate = setDate.toLocaleDateString(locale, dateOptions);


new Vue({
  el: '#app',
  data: {
    todoDate: readableDate,
    taskList:[
    'Hacer la compra',
    'Pasear al perro',
    'Llevar el coche al taller',
    'Comprar ropa',
  ],
  taskItem: '',
  todotitle: 'Mi lista de Tareas',
  isEditing: false,
},
  methods:{
      addTask: function(){
        if (this.taskItem === '')
          alert('Debes escribir una tarea')
        else {
          this.taskList.push(this.taskItem);
          this.taskItem = '';
        }
      },
      setTitle: function (event){
        this.todotitle= event.target.value;
        this.isEditing = false;
      }
      ,
      removeTodo: function (index) {
        this.taskList.splice(index,1);
      },
    addTaskFocus: function(){
      this.$refs.taskInput.focus();
    }
  },
  computed: {
    taskListEmpty: function(){
      return this.taskList.length === 0;
    }
  }
});
